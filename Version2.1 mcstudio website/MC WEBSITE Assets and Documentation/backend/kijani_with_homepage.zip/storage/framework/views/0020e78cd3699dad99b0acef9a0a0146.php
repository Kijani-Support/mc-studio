<h2
    <?php echo e($attributes->class(['filament-tables-header-heading text-xl font-bold tracking-tight'])); ?>

>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH D:\Apps\laragon\www\kv3\vendor\filament\tables\src\/../resources/views/components/header/heading.blade.php ENDPATH**/ ?>