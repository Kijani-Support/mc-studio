<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH D:\Apps\laragon\www\kv3\vendor\filament\forms\src\/../resources/views/components/group.blade.php ENDPATH**/ ?>