<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 
    <?php if($subject = $attributes->get('subject')): ?>

    <title><?php echo e($subject); ?></title>
    
    <?php endif; ?>
</head>
<body>
    <div class="flex items-center justify-center min-h-screen p-5 bg-green-300 min-w-screen">
        
        <div class="flex flex-col">

            <?php echo $__env->make('partials.mail.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <div class="bg-white dark:bg-darkmode-700 rounded-lg">
                <?php echo e($slot); ?>

            </div>
            
            <?php echo $__env->make('partials.mail.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

    </div>
</body>
</html><?php /**PATH D:\Apps\laragon\www\kv3\resources\views/emails/base.blade.php ENDPATH**/ ?>