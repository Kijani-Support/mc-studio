@extends('layouts.app')

@section('title', 'Home')

@section('content')
<div class="home_video_top">
  <div class="overlay"></div>
  <video id="background-video" autoplay loop muted poster="images/hero_bg.jpg">
      <source src="images/hero.mp4" type="video/mp4">
      Your browser does not support the video tag.
  </video>
  <!-- Header Start -->
  <header class="main_header">
      <div class="container-fluid">
          <nav class="navbar navbar-expand-xl">
              <div class="d-inline-flex align-items-center col-md-2 mb-2 mb-md-0">
                  <a href="#" class="">
                      <img src="images/logo.png" alt="Kijani" class="img-fluid">
                  </a>
              </div>
          <div class="collapse col-12 col-md-auto justify-content-center navbar-collapse" id="navbarNav">
              <ul class="nav mb-2 mb-md-0">
                  <li><a href="#" class="nav-link active">Home</a></li>
                  <li><a href="#" class="nav-link">Dev Portal</a></li>
                  <li><a href="#" class="nav-link">Docs</a></li>
                  <li><a href="#" class="nav-link">Pricing</a></li>
                  <li><a href="#" class="nav-link">Contact Us</a></li>
              </ul>
          </div>
          <div class="col-md-2 hide_sm">
              <button type="button" class="btn btn-outline-primary"><span class="cricle_talk"></span> Let's Talk</button>
          </div>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <i class="bi bi-list"></i>
          </button>
          </nav>
      </div>
  </header>
  <!-- Header End -->

  <!-- Heor Start -->
  <section class="hero_section">
      <div class="container">
          <div class="row">
              <div class="col-md-6">
                  <div class="hero_content">
                      <h1>Put Your Startup on Autopilot with <span>Kijani</span></h1>
                      <p>Need a modern system to intergrate your team and different locations? Let's get you set- up to blossom!</p>
                      <a href="#" class="btn btn-primary">Register Now! <i class="bi bi-arrow-right ms-2"></i></a>
                  </div>
              </div>
              <div class="col-md-6">
                  <svg width="602" height="920" viewBox="0 0 602 920" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M123.703 685.957L122.803 521.992H146.194L421.489 230H582.528L268.548 562.422H247.406L123.703 685.957ZM0 920V0H134.499V920H0ZM436.334 920L188.928 592.07L281.593 498.184L601.421 920H436.334Z" fill="white"/>
                  </svg>
              </div>
          </div>
      </div>
  </section>
  <!-- Heor End -->
</div>

<!-- Imagine Start -->
<section class="imagine_section">
  <div class="row g-0">
      <div class="col-md-5">
          <div class="imagine_inside">
              <h2>Imagine <br>this for batter</h2>
              <a href="#" class="btn btn-primary">Book a Demo <i class="bi bi-arrow-right ms-2"></i></a>
          </div>
      </div>
      <div class="col-md-7">
          <ul>
              <li>
                  <span><img src="images/timepay.svg" alt="Time Pay" title="" class="img-fluid" /></span> No more Frankenstein accounting
              </li>
              <li>
                  <span><img src="images/focus.svg" alt="Focus" title="" class="img-fluid" /></span> Focus on what matters
              </li>
              <li>
                  <span><img src="images/target.svg" alt="Target" title="" class="img-fluid" /></span> Data-driven decisions, lightning fast
              </li>
              <li>
                  <span><img src="images/hourglass.svg" alt="Hourglass" title="" class="img-fluid" /></span> Funding-ready, in record time
              </li>
          </ul>
      </div>
  </div>
</section>
<!-- Imagine End -->

<!-- Blog Start -->
<section class="blog_section">
  <h2 class="title2">But wait, there's more!</h2>
  <div class="row g-0">
      <div class="col-md-4">
          <a href="#" class="blog_item">
              <img src="images/blog1.jpg" alt="" title="" class="img-fluid" />
              <div class="effect_inner">
                  <i class="bi bi-arrow-up-right"></i>
                  <h3>Effortless onboarding for API-powered solutions</h3>
                  <p>The Kijani family is a hub of passionate founders, industry experts, and investors. Get plugged into a network of support, share best practices, and learn from the best.</p>
              </div>
          </a>
      </div>
      <div class="col-md-4">
          <a href="#" class="blog_item">
              <img src="images/blog2.jpg" alt="" title="" class="img-fluid" />
              <div class="effect_inner">
                  <i class="bi bi-arrow-up-right"></i>
                  <h3>Unlock a network of opportunities</h3>
                  <p>The Kijani family is a hub of passionate founders, industry experts, and investors. Get plugged into a network of support, share best practices, and learn from the best.</p>
              </div>
          </a>
      </div>
      <div class="col-md-4">
          <a href="#" class="blog_item">
              <img src="images/blog3.jpg" alt="" title="" class="img-fluid" />
              <div class="effect_inner">
                  <i class="bi bi-arrow-up-right"></i>
                  <h3>Join a thriving community</h3>
                  <p>The Kijani family is a hub of passionate founders, industry experts, and investors. Get plugged into a network of support, share best practices, and learn from the best.</p>
              </div>
          </a>
      </div>
  </div>
</section>
<!-- Blog End -->

<!-- Advantage Start -->
<section class="advantage_section">
  <div class="container">
      <h2 class="title2">The Kijani advantage is clear</h2>
      <span class="tagline"></span>
      <p>Innovative tactics drive optimal engagement for digital success and audience connection.</p>
      <div class="row pt-5">
          <div class="col-md-4">
              <div class="adv_item">
                  <img src="images/adv1.svg" alt="" title="" class="img-fluid" />
                  <h3>Built for Pre-Seed Success</h3>
                  <a href="#" class="btn btn-primary">Learn More <i class="bi bi-arrow-right ms-2"></i></a>
              </div>
          </div>
          <div class="col-md-4">
              <div class="adv_item">
                  <img src="images/adv2.svg" alt="" title="" class="img-fluid" />
                  <h3>Scalability You Can Count On</h3>
                  <a href="#" class="btn btn-primary">Learn More <i class="bi bi-arrow-right ms-2"></i></a>
              </div>
          </div>
          <div class="col-md-4">
              <div class="adv_item">
                  <img src="images/adv3.svg" alt="" title="" class="img-fluid" />
                  <h3>Focus on Your Vision</h3>
                  <a href="#" class="btn btn-primary">Learn More <i class="bi bi-arrow-right ms-2"></i></a>
              </div>
          </div>
      </div>
  </div>
</section>
<!-- Advantage End -->

<!-- Pricing Start -->
<section class="pricing">
  <div class="overlay2"></div>
  <video id="background-video" autoplay loop muted poster="images/hero_bg.jpg">
      <source src="images/hero.mp4" type="video/mp4">
      Your browser does not support the video tag.
  </video>
  <div class="above_video">
      <h2 class="title2">Pricing Plans</h2>
      <p>The Best Solution for Our Clients</p>
      <div class="row g-0 mt-5">
          <div class="col-md-4">
              <div class="pricing_item">
                  <span>Starter Plan</span>
                  <h3>$500</h3>
                  <ul>
                      <li>Responsive website design and development (5 pages)</li>
                      <li>Basic SEO</li>
                      <li>Social media management</li>
                  </ul>
                  <a href="#" class="btn btn-primary">Book Now <i class="bi bi-arrow-right ms-2"></i></a>
              </div>
          </div>
          <div class="col-md-4">
              <div class="pricing_item">
                  <span>Business Plan</span>
                  <h3>$1000</h3>
                  <ul>
                      <li>Responsive website design and development (10 pages)</li>
                      <li>Advanced SEO</li>
                      <li>Social media management</li>
                      <li>PPC advertising campaign</li>
                  </ul>
                  <a href="#" class="btn btn-primary">Book Now <i class="bi bi-arrow-right ms-2"></i></a>
              </div>
          </div>
          <div class="col-md-4">
              <div class="pricing_item">
                  <span>Premium Plan</span>
                  <h3>$2000</h3>
                  <ul>
                      <li>Advanced Business plan</li>
                      <li>Regular content creation</li>
                      <li>Performance analysis and monthly reporting</li>
                  </ul>
                  <a href="#" class="btn btn-primary">Book Now <i class="bi bi-arrow-right ms-2"></i></a>
              </div>
          </div>
      </div>
  </div>
</section>
<!-- Pricing End -->

<!-- Schedule Start -->
<section class="schedule_section">
  <div class="container">
      <h2 class="title2">Ready to ditch the hustle and scale your startup to new heights?</h2>
      <p>Onboard your API-enabled tech solution with Kijani today!</p>
      <p>Visit us at kijani.co and unleash the full potential of your business. </p>
      <p>Remember, the sooner you streamline, the sooner you dominate. Let's make history together!</p>
      <a href="#" class="btn btn-primary mt-5">Schedule a Demo Call <i class="bi bi-arrow-right ms-2"></i></a>
  </div>
</section>
<!-- Schedule End -->

<!-- Footer Start -->
<footer class="main_footer">
  <div class="container">
      <div class="custom_footer_row">
          <div class="custom_footer_col1">
              <a href="#" class="footer_logo">
                  <img src="images/logo.png" alt="Kijani" class="img-fluid">
              </a>
              <p>We're the all-in-one ERP (Enterprise Resource Planning) built specifically for audacious pre-seed tech startups like you.</p>
              <address>Kijani.co2024 © All right reserved</address>
          </div>
          <div class="custom_footer_col2">
              <h4>Our Services</h4>
              <ul>
                  <li>
                      <a href="#">SEO Marketing</a>
                  </li>
                  <li>
                      <a href="#">Research Topic Trends</a>
                  </li>
                  <li>
                      <a href="#">Email Marketing</a>
                  </li>
                  <li>
                      <a href="#">Google PPC</a>
                  </li>
              </ul>
          </div>
          <div class="custom_footer_col3">
              <h4>Explore More</h4>
              <ul>
                  <li>
                      <a href="#">About Us</a>
                  </li>
                  <li>
                      <a href="#">Feature</a>
                  </li>
                  <li>
                      <a href="#">Our Works</a>
                  </li>
                  <li>
                      <a href="#">Resource</a>
                  </li>
                  <li>
                      <a href="#">Privacy Policy</a>
                  </li>
              </ul>
          </div>
          <div class="custom_footer_col4">
              <h4>Contact Us</h4>
              <p><span class="icon_bb"><i class="bi bi-geo-alt-fill"></i></span> Jl. Medan Merdeka No. 35 Jakarta Selatan</p>
              <p><span class="icon_bb"><i class="bi bi-telephone-fill"></i></span> (021) 234567</p>
              <p><span class="icon_bb"><i class="bi bi-phone-fill"></i></span> +62 812 9188 72</p>
          </div>
      </div>
  </div>
</footer>
<!-- Footer End -->




@push('scripts')
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" 
          integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" 
          crossorigin="anonymous">
  </script>    
@endpush

@endsection
