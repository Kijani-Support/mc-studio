<?php return array (
  'subscription-expired' => 'App\\Http\\Livewire\\SubscriptionExpired',
);