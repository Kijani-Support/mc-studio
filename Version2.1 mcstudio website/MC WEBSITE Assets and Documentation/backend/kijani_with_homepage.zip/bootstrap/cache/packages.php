<?php return array (
  'akaunting/laravel-money' => 
  array (
    'providers' => 
    array (
      0 => 'Akaunting\\Money\\Provider',
    ),
  ),
  'barryvdh/laravel-debugbar' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\Debugbar\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Debugbar' => 'Barryvdh\\Debugbar\\Facades\\Debugbar',
    ),
  ),
  'barryvdh/laravel-dompdf' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\DomPDF\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Pdf' => 'Barryvdh\\DomPDF\\Facade\\Pdf',
      'PDF' => 'Barryvdh\\DomPDF\\Facade\\Pdf',
    ),
  ),
  'blade-ui-kit/blade-heroicons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Heroicons\\BladeHeroiconsServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Icons\\BladeIconsServiceProvider',
    ),
  ),
  'buildix/timex' => 
  array (
    'providers' => 
    array (
      0 => 'Buildix\\Timex\\TimexServiceProvider',
    ),
    'aliases' => 
    array (
      'Timex' => 'Buildix\\Timex\\Facades\\Timex',
    ),
  ),
  'eduardokum/laravel-mail-auto-embed' => 
  array (
    'providers' => 
    array (
      0 => 'Eduardokum\\LaravelMailAutoEmbed\\ServiceProvider',
    ),
  ),
  'fedeisas/laravel-mail-css-inliner' => 
  array (
    'providers' => 
    array (
      0 => 'Fedeisas\\LaravelMailCssInliner\\LaravelMailCssInlinerServiceProvider',
    ),
  ),
  'filament/filament' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\FilamentServiceProvider',
    ),
  ),
  'filament/forms' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Forms\\FormsServiceProvider',
    ),
  ),
  'filament/notifications' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Notifications\\NotificationsServiceProvider',
    ),
  ),
  'filament/support' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Support\\SupportServiceProvider',
    ),
  ),
  'filament/tables' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Tables\\TablesServiceProvider',
    ),
  ),
  'filipfonal/filament-log-manager' => 
  array (
    'providers' => 
    array (
      0 => 'FilipFonal\\FilamentLogManager\\FilamentLogManagerServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentLogManager' => 'FilipFonal\\FilamentLogManager\\Facades\\FilamentLogManager',
    ),
  ),
  'flowframe/laravel-trend' => 
  array (
    'providers' => 
    array (
      0 => 'Flowframe\\Trend\\TrendServiceProvider',
    ),
    'aliases' => 
    array (
      'Trend' => 'Flowframe\\Trend\\TrendFacade',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'koalafacade/filament-crash' => 
  array (
    'providers' => 
    array (
      0 => 'KoalaFacade\\FilamentCrash\\FilamentCrashServiceProvider',
    ),
  ),
  'konnco/filament-import' => 
  array (
    'providers' => 
    array (
      0 => 'Konnco\\FilamentImport\\FilamentImportServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laraveldaily/laravel-invoices' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelDaily\\Invoices\\InvoiceServiceProvider',
    ),
    'aliases' => 
    array (
      'Invoice' => 'LaravelDaily\\Invoices\\Facades\\Invoice',
    ),
  ),
  'leandrocfe/filament-apex-charts' => 
  array (
    'providers' => 
    array (
      0 => 'Leandrocfe\\FilamentApexCharts\\FilamentApexChartsServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentApexCharts' => 'Leandrocfe\\FilamentApexCharts\\Facades\\FilamentApexCharts',
    ),
  ),
  'livewire/livewire' => 
  array (
    'providers' => 
    array (
      0 => 'Livewire\\LivewireServiceProvider',
    ),
    'aliases' => 
    array (
      'Livewire' => 'Livewire\\Livewire',
    ),
  ),
  'maatwebsite/excel' => 
  array (
    'providers' => 
    array (
      0 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
    ),
    'aliases' => 
    array (
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'pxlrbt/filament-activity-log' => 
  array (
    'providers' => 
    array (
      0 => '\\pxlrbt\\FilamentActivityLog\\FilamentActivityLogServiceProvider',
    ),
  ),
  'ryangjchandler/blade-capture-directive' => 
  array (
    'providers' => 
    array (
      0 => 'RyanChandler\\BladeCaptureDirective\\BladeCaptureDirectiveServiceProvider',
    ),
    'aliases' => 
    array (
      'BladeCaptureDirective' => 'RyanChandler\\BladeCaptureDirective\\Facades\\BladeCaptureDirective',
    ),
  ),
  'sgcomptech/filament-ticketing' => 
  array (
    'providers' => 
    array (
      0 => 'Sgcomptech\\FilamentTicketing\\FilamentTicketingServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentTicketing' => 'Sgcomptech\\FilamentTicketing\\Facades\\FilamentTicketing',
    ),
  ),
  'smodav/mpesa' => 
  array (
    'providers' => 
    array (
      0 => 'SmoDav\\Mpesa\\Laravel\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'STK' => 'SmoDav\\Mpesa\\Laravel\\Facades\\STK',
      'Simulate' => 'SmoDav\\Mpesa\\Laravel\\Facades\\Simulate',
      'Registrar' => 'SmoDav\\Mpesa\\Laravel\\Facades\\Registrar',
      'Identity' => 'SmoDav\\Mpesa\\Laravel\\Facades\\Identity',
    ),
  ),
  'spatie/laravel-activitylog' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Activitylog\\ActivitylogServiceProvider',
    ),
  ),
  'spatie/laravel-ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Spatie\\LaravelIgnition\\Facades\\Flare',
    ),
  ),
  'spatie/laravel-medialibrary' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\MediaLibrary\\MediaLibraryServiceProvider',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'squirephp/countries' => 
  array (
    'providers' => 
    array (
      0 => 'Squire\\CountriesServiceProvider',
    ),
  ),
  'squirephp/countries-en' => 
  array (
    'providers' => 
    array (
      0 => 'Squire\\CountriesEnServiceProvider',
    ),
  ),
  'squirephp/currencies' => 
  array (
    'providers' => 
    array (
      0 => 'Squire\\CurrenciesServiceProvider',
    ),
  ),
  'squirephp/currencies-en' => 
  array (
    'providers' => 
    array (
      0 => 'Squire\\CurrenciesEnServiceProvider',
    ),
  ),
  'squirephp/model' => 
  array (
    'providers' => 
    array (
      0 => 'Squire\\ModelServiceProvider',
    ),
  ),
  'squirephp/repository' => 
  array (
    'providers' => 
    array (
      0 => 'Squire\\RepositoryServiceProvider',
    ),
    'aliases' => 
    array (
      'RepositoryManager' => 'Squire\\Repository\\Facades\\Repository',
    ),
  ),
  'thedoctor0/laravel-factory-generator' => 
  array (
    'providers' => 
    array (
      0 => 'TheDoctor0\\LaravelFactoryGenerator\\FactoryGeneratorServiceProvider',
    ),
  ),
  'z3d0x/filament-logger' => 
  array (
    'providers' => 
    array (
      0 => 'Z3d0X\\FilamentLogger\\FilamentLoggerServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentLogger' => 'Z3d0X\\FilamentLogger\\Facades\\FilamentLogger',
    ),
  ),
);